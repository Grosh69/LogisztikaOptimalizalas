import cv2
import json
import time
import paho.mqtt.client as mqtt
from picamera2 import Picamera2
from picfuncs import get_border_coordiantes, get_positions

# 🔹 MQTT broker adatok
BROKER = "172.22.0.220"  # a Mosquitto broker IP-je
PORT = 1883
TOPIC = "/convoy/camera/positions"

# 🔹 Kamera inicializálása
print("📷 Kamera inicializálása...")
picamera2 = Picamera2()
picamera2.configure(
    picamera2.create_video_configuration(
        sensor={"output_size": (1640, 1232)}, main={"format": "RGB888"}
    )
)
picamera2.start()
time.sleep(2)

# 🔹 ArUco detektor inicializálása
arucoDict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_5X5_50)
arucoParams = cv2.aruco.DetectorParameters_create()

# 🔹 MQTT kapcsolat beállítása
client = mqtt.Client("CameraPublisher")
client.connect(BROKER, PORT, 60)
client.loop_start()
print("📡 MQTT kapcsolat létrejött brokerrel:", BROKER)

# 🔹 Határoló markerek (pálya keret)
print("🔍 Pálya határainak keresése...")
border_coords = get_border_coordiantes(picamera2, arucoDict, arucoParams)
while len(border_coords) != 2:
    print("⏳ Border markerek újrapróbálása...")
    border_coords = get_border_coordiantes(picamera2, arucoDict, arucoParams)

print("✅ Border koordináták megvannak:", border_coords)

# 🔹 ROI kiszámítása a határokból
top_left_border = (border_coords[0][0], border_coords[1][1])
bottom_right_border = (border_coords[1][0], border_coords[0][1])

# 🔹 Fő ciklus
print("🚗 Autók követése indul... (nyomj Ctrl+C a leállításhoz)")
while True:
    try:
        frame = picamera2.capture_array()
        roi = frame[
            top_left_border[1] : bottom_right_border[1],
            top_left_border[0] : bottom_right_border[0],
        ]
        (corners, ids, _) = cv2.aruco.detectMarkers(
            roi, arucoDict, parameters=arucoParams
        )

        car_positions = {}
        if ids is not None and len(ids) > 0:
            car_positions = get_positions(corners, ids, border_coords)

        if car_positions:
            payload = json.dumps(car_positions)
            client.publish(TOPIC, payload)
            print("📨 MQTT publish:", payload)

        time.sleep(0.1)

    except KeyboardInterrupt:
        print("🛑 Kamera leállítva felhasználó által.")
        break
    except Exception as e:
        print("⚠️ Hiba:", e)
        time.sleep(0.5)

client.loop_stop()
picamera2.stop()
cv2.destroyAllWindows()
print("✅ Program leállt.")
