# car_client.py
import time
import json
import paho.mqtt.client as mqtt
import RPi.GPIO as GPIO
import threading

# --- KONFIGURÁCIÓ ---
BROKER = "172.22.0.220"  # MQTT broker IP (ugyanaz, mint az Optimizeré)
PORT = 1883
CAR_ID = "car1"  # ezen változtass: car1 vagy car2

# Motorvezérlő GPIO (példa, igazítsd a tiétekhez)
LEFT_MOTOR_FWD = 17
LEFT_MOTOR_BWD = 18
RIGHT_MOTOR_FWD = 22
RIGHT_MOTOR_BWD = 23

GPIO.setmode(GPIO.BCM)
for pin in [LEFT_MOTOR_FWD, LEFT_MOTOR_BWD, RIGHT_MOTOR_FWD, RIGHT_MOTOR_BWD]:
    GPIO.setup(pin, GPIO.OUT)
    GPIO.output(pin, GPIO.LOW)

# MQTT kliens létrehozása
client = mqtt.Client(CAR_ID)

current_command = "stop"
command_lock = threading.Lock()


def set_motors(lf, lb, rf, rb):
    GPIO.output(LEFT_MOTOR_FWD, lf)
    GPIO.output(LEFT_MOTOR_BWD, lb)
    GPIO.output(RIGHT_MOTOR_FWD, rf)
    GPIO.output(RIGHT_MOTOR_BWD, rb)


def stop():
    set_motors(0, 0, 0, 0)


def forward():
    set_motors(1, 0, 1, 0)


def backward():
    set_motors(0, 1, 0, 1)


def turn_left():
    set_motors(0, 1, 1, 0)


def turn_right():
    set_motors(1, 0, 0, 1)


# --- MQTT callback-ek ---
def on_connect(client, userdata, flags, rc):
    print(f"[{CAR_ID}] MQTT connected.")
    client.subscribe(f"/convoy/{CAR_ID}/cmd")


def on_message(client, userdata, msg):
    global current_command
    data = msg.payload.decode("utf-8")
    print(f"[{CAR_ID}] Command received: {data}")
    try:
        cmd = json.loads(data)
        with command_lock:
            current_command = cmd.get("action", "stop")
    except:
        with command_lock:
            current_command = "stop"


# --- Motorvezérlés szál ---
def control_loop():
    while True:
        with command_lock:
            cmd = current_command
        if cmd == "forward":
            forward()
        elif cmd == "backward":
            backward()
        elif cmd == "left":
            turn_left()
        elif cmd == "right":
            turn_right()
        else:
            stop()
        time.sleep(0.1)


# --- Indítás ---
client.on_connect = on_connect
client.on_message = on_message
client.connect(BROKER, PORT, 60)

control_thread = threading.Thread(target=control_loop, daemon=True)
control_thread.start()

client.loop_forever()
